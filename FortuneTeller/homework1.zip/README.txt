1. Wilson Ng Tse
2. wilsonng1ve@gmail.com
3. Individual project
4. This project took 2 hours to complete
5. Version:Android 6.0.1
Screen size: 5.1 inches 1440 x 2560 pixels
6. No comments